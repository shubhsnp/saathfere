// Import dotenv using dynamic import, which works for both ESM and CommonJS
import('dotenv').then(dotenv => dotenv.config());

import express from 'express';
import './src/config/db.js';
import authRoutes from './src/routes/authRoutes.js';
import userRoutes from './src/routes/userRoutes.js';

const app = express();

app.use(express.json()); // Using built-in Express middleware for JSON parsing
app.use('/api', userRoutes);  // Mount user routes at /api prefix
app.use('/', authRoutes);  // Mount user routes at /api prefix

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
