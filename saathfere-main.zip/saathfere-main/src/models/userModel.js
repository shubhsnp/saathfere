import { Schema, model } from 'mongoose';

const UserSchema = new Schema({
    mobile_number: {
        type: String,
        maxLength: 15,
        unique: true,
        index: true,
        required: true,
    },
    country_code: { type: String, required: true },
    first_name: { type: String },
    last_name: { type: String },
    day: { type: String, maxLength: 2 },
    month: { type: String, maxLength: 2 },
    year: { type: String, maxLength: 4 },
    specialization: { type: String },
    education: { type: String },
    photo_url: { type: String },
    gender: {
        type: String,
        default: "M",
        enum: ['M', 'F'],
    },
    type: {
        type: String,
        default: "admin",
        enum: ['admin', 'user', 'guest'],
    },
    created_on: { type: String, default: Date.now },
});

export default model('User', UserSchema);
