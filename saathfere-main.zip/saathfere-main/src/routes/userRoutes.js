import { Router } from 'express';
import { checkUserExist, getUser, listUsers, upsertUser } from '../controllers/userController.js';
const router = Router();

router.post('/upsert-user', upsertUser);
router.get('/check-user-exist', checkUserExist);
router.get('/list-users', listUsers); // Add middleware later
router.get('/get-user', getUser); // Add middleware later

export default router;
