import { Router } from 'express';
import { generateToken, refreshToken } from '../controllers/authController.js';

const router = Router();

// Route to generate new tokens
router.post('/generate-token', generateToken);
router.post('/refresh-token', refreshToken);

export default router;
