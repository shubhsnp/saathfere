import { randomBytes } from 'crypto';

// Generate a 256-bit (32-byte) secret
const secret = randomBytes(32).toString('hex');
console.log(secret); // Save this in your environment variables
