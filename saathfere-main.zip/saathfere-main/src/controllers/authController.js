import jwt from 'jsonwebtoken';
import redisClient from '../utils/redisClient.js';

export async function generateToken(req, res) {
    try {
        const { user_id } = req.body;
        // Create JWT access token
        const accessToken = jwt.sign({ id: user_id }, process.env.JWT_SECRET, { expiresIn: '1d' });
        const refreshToken = jwt.sign({ id: user_id }, process.env.REFRESH_TOKEN_SECRET, { expiresIn: '7d' });
        const expiresIn = 24 * 60 * 60;

        // // Store refresh token in Redis
        await redisClient.set(user_id.toString(), refreshToken, {
            EX: 7 * 24 * 60 * 60 // Expires in 7 days
        });

        res.status(200).json({ accessToken: accessToken, refreshToken: refreshToken, expiresIn: expiresIn });
    } catch (err) {
        res.status(500).json({ message: 'Error generating tokens', error: err });
    }
}


export async function refreshToken(req, res) {
    const { token, user_id } = req.body; // Client sends the refresh token in the body

    if (!token) {
        return res.status(401).send({ message: 'Refresh token required' });
    }

    try {
        // Verify the refresh token
        const storedToken = await redisClient.get(user_id.toString());

        if (!storedToken || token !== storedToken) {
            return res.status(403).send({ message: 'Invalid refresh token' });
        }

        // Generate new access token
        const accessToken = jwt.sign({ id: user_id }, process.env.JWT_SECRET, { expiresIn: '1d' });
        const refreshToken = jwt.sign({ id: user_id }, process.env.REFRESH_TOKEN_SECRET, { expiresIn: '7d' });
        const expiresIn = 24 * 60 * 60;

        // Store refresh token in Redis
        await redisClient.set(user_id.toString(), refreshToken, {
            EX: 24 * 60 * 60 // Expires in 7 days
        });

        res.json({ accessToken: accessToken, refreshToken: refreshToken, expiresIn: expiresIn });
    } catch (err) {
        if (err.name === 'TokenExpiredError') {
            res.status(403).send({ message: 'Refresh token expired' });
        } else {
            res.status(403).send({ message: 'Invalid token' });
        }
    }
}

