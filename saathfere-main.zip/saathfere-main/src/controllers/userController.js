import db from '../config/db.js';

export async function upsertUser(req, res) {
    const { user_id, ...otherFields } = req.body;
    let query, params;

        try {
            const existingUserQuery = 'SELECT * FROM users WHERE user_id = ?';
            const [existingUser] = await db.query(existingUserQuery, [user_id]);

            if (existingUser.length > 0) {
                // Update existing user
                const updateFields = Object.keys(otherFields).map(field => `${field} = ?`).join(', ');
                query = `UPDATE users SET ${updateFields} WHERE user_id = ?`;
                params = [...Object.values(otherFields), user_id];
            } else {
                // Insert new user
                const fields = Object.keys(req.body).join(', ');
                const values = Object.keys(req.body).map(() => '?').join(', ');
                query = `INSERT INTO users (${fields}) VALUES (${values})`;
                params = Object.values(req.body);
            }

            await db.query(query, params);

            const [updatedUser] = await db.query(existingUserQuery, [user_id]);

            res.status(200).json({
                user: updatedUser[0],
                message: 'User created or updated successfully',
                status_code: 200
            });
        } catch (err) {
            console.error("Error upserting user:", err);
            res.status(400).json(err);
        }
}

export async function getUser(req, res) {
    const { user_id } = req.body;

    if (user_id) {
        try {
            const query = 'SELECT * FROM users WHERE user_id = ?';
            const [user] = await db.query(query, [user_id]);

            if (user.length > 0) {
                res.status(200).json({
                    user: user[0],
                    message: 'User fetched successfully',
                    status_code: 200
                });
            } else {
                res.status(404).json({
                    user: null,
                    message: 'User does not exist',
                    status_code: 404
                });
            }
        } catch (err) {
            console.error("Error fetching user:", err);
            res.status(400).json(err);
        }
    } else {
        res.status(400).json({
            message: 'Mobile number is required',
            status_code: 400
        });
    }
}

export async function checkUserExist(req, res) {
    const { email } = req.body;

    if (email) {
        try {
            const query = 'SELECT COUNT(*) as count FROM users WHERE email = ?';
            const [result] = await db.query(query, [email]);

            if (result[0].count > 0) {
                res.status(200).json({
                    user: { exists: true },
                    message: 'User exists',
                    status_code: 200
                });
            } else {
                res.status(404).json({
                    user: { exists: false },
                    message: 'User does not exist',
                    status_code: 404
                });
            }
        } catch (err) {
            console.error("Error checking user existence", err);
            res.status(400).json(err);
        }
    } else {
        res.status(400).json({
            message: 'Mobile number is required',
            status_code: 400
        });
    }
}

export async function listUsers(req, res) {
    try {
        const query = 'SELECT * FROM users';
        const [users] = await db.query(query);

        if (users.length > 0) {
            res.status(200).json({
                users,
                message: 'Users fetched successfully',
                status_code: 200
            });
        } else {
            res.status(404).json({
                users: null,
                message: 'No users found',
                status_code: 404
            });
        }
    } catch (err) {
        console.error("Error listing users:", err);
        res.status(400).json(err);
    }
}
