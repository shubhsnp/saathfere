import jwt from 'jsonwebtoken';

const auth = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];  // Format: "Bearer TOKEN"

    if (token == null) {
        return res.status(401).json({ message: "Token is required for access" });
    }

    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) {
            const errorMessage = err.name === 'TokenExpiredError' ? "Token has expired" : "Token is invalid";
            return res.status(403).json({ message: errorMessage });
        }

        req.user = user;  // If no error, save the decoded token payload to request for use in your route
        next();  // Continue to the next middleware or route handler
    });
};

export default auth;
