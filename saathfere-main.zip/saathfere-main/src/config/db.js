import { createPool } from 'mysql2/promise';
import dotenv from 'dotenv';
dotenv.config();

const pool = createPool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// Utility function to replace undefined with null
function replaceUndefinedWithNull(params) {
    if (Array.isArray(params)) {
        return params.map(param => param === undefined ? null : param);
    } else if (typeof params === 'object' && params !== null) {
        return Object.keys(params).reduce((acc, key) => {
            acc[key] = params[key] === undefined ? null : params[key];
            return acc;
        }, {});
    }
    return params;
}

// Wrapper function to sanitize query parameters
async function sanitizedQuery(sql, params) {
    const sanitizedParams = replaceUndefinedWithNull(params);
    console.log(sanitizedParams);
    return pool.execute(sql, sanitizedParams);
}

async function transaction(callback) {
    const connection = await pool.getConnection();
    try {
        await connection.beginTransaction();
        await callback(connection);
        await connection.commit();
    } catch (err) {
        await connection.rollback();
        throw err;
    } finally {
        connection.release();
    }
}

export default {
    query: sanitizedQuery, // Use sanitized query instead of direct query
    transaction,
    pool // Optional: if you need direct access to the pool
};
