**Server Setup**
----------------

1.  Install Node Js >=18
    
2.  Run **npm install** to get packages and dependencies
    
3.  Install **nodemon** to make server run and adapt changes dynamically rather than starting it every time on making changes
    
4.  Install **Redis server** on local machine and start redis server
    
5.  Setup mongodb using Mongo Compass or Atlas
    
6.  Use **npm run dev** to start server and check for api
